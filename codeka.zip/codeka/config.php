<?php
$Usuario="";  /*root*/
$Password="";
$Servidor=""; /*localhost*/
$BaseDeDatos="";
?>
